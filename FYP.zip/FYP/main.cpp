#include <opencv4/opencv2/opencv.hpp>
#include <iostream>
#include <opencv4/opencv2/core/mat.hpp>
#include <opencv4/opencv2/imgcodecs.hpp>
#include <sdsl/vectors.hpp>
#include <sdsl/bit_vectors.hpp>
#include <sdsl/bp_support.hpp>
#include <sdsl/suffix_trees.hpp>
#include <fstream>
#include <string>

using namespace cv;
using namespace sdsl;
using namespace std;

void compress_bit(Mat3b image);
void compress_int(Mat3b image);
void test();
void compress_file(const String& file_name);
void load();
int main(int argc, char ** argv )
{
    if ( argc != 2 )
    {
        printf("usage: DisplayImage.out <Image_Path>\n");
        return -1;
    }
    Mat3b image = imread( argv[1]);
    if ( !image.data )
    {
        printf("No image data \n");
        return -1;
    }
    //compress_bit(image);
    //namedWindow("Display Image", WINDOW_AUTOSIZE );
    //imshow("Display Image", image);
    //waitKey(0);
    //std::cout << image.dims << std::endl;
    String file_name = "test-data/test3";
    compress_file(file_name);
    load();
    return 0;
}

void compress_file(const String& file_name){
  ifstream fp(file_name);
  if (fp) {
    fp.seekg (0, std::ifstream::end);
    int length = fp.tellg();
    cout << "Original size" << (double)length/1000 << "kb" << endl;
    fp.seekg (0, std::ifstream::beg);
    char * buffer = new char [length];
    fp.read (buffer,length);
    if (fp)
      std::cout << "all characters read successfully." << endl;
    else
      std::cout << "error: only " << fp.gcount() << " could be read" << endl;

    cout << "# Byte alphabet example\n" << endl;

    csa_bitcompressed<> csa;
    construct_im(csa, "abcf", 1);
    cout << "bp compression: " << size_in_bytes(csa) << "bytes" << endl;
    store_to_file(csa, "test.sdsl");
    fp.close();
    delete[] buffer;
  }
}

void compress_bit(Mat3b image){
  bit_vector v(image.rows*image.cols*24);
  for (int i=0; i<image.rows; i++){
    for (int j=0; j<image.cols; j++) {
      Vec3b pixel = image(i, j);
      for(int k=0; k<3; k++){
        uchar bgr_ele = pixel[k];
        for(int l=sizeof(unsigned char)*8-1; l; bgr_ele>>=1u, l--){
          v[i*image.cols*24 + j*24 + k*8 + l] = bgr_ele&1u;
        }
      }
    }
  }

  cout << "Original size: " << size_in_mega_bytes(v) << "mb"<< endl;

  rrr_vector<63> rrrb(v);
  cout << "rrrb: " << size_in_mega_bytes(rrrb) << "mb" << endl;
  sd_vector<> sdb(v);
  cout << "sdb: " << size_in_mega_bytes(rrrb) << "mb" << endl;
  bp_support_sada<> bps(&v);
  cout << "bp compression: " << size_in_mega_bytes(bps) << "mb" << endl;

}

void compress_int(Mat3b image){
  int_vector<> v(image.rows*image.cols*3);
  for (int i=0; i<image.rows; i++){
    for (int j=0; j<image.cols; j++) {
      Vec3b pixel = image(i, j);
      for(int k=0; k<3; k++){
        v[i*image.cols*3 + j*3 + k] = pixel[k];
      }
    }
  }

  cout << "Original size: " << size_in_mega_bytes(v) << "mb"<< endl;
  util::bit_compress(v);
  enc_vector<> ev(v);
  cout << "rrrb compression: " << size_in_mega_bytes(ev) << "mb" << endl;
}

void test(){
  ofstream fp;
  fp.open("test-data/test2");
  for(int i=0; i<10000; i++){
    fp << "testt";
  }
  fp.close();
}

void load(){
  //cst_sct3<csa_wt<wt_huff<rrr_vector<>>>, lcp_dac<>> read;
  //
  //ofstream fp;
  //fp.open("final");
  csa_bitcompressed<> csa;
  load_from_file(csa, "test.sdsl");
  cout << extract(csa, 0, csa.size()-2);
}